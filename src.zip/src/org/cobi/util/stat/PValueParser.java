/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.stat;

import cern.colt.list.DoubleArrayList;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.cobi.util.text.LocalFileFunc;

/**
 *
 * @author user
 */
public class PValueParser {

  public void readPValues(String pValueFilePath, int index) throws Exception {
    BufferedReader br = LocalFileFunc.getBufferedReader(pValueFilePath);
    String line = br.readLine();
    String[] cells;
    List<String[]> pvalueMap = new ArrayList<String[]>();
    String[] pvs = null;
    DoubleArrayList pValueList = new DoubleArrayList();
    double[] adjustPValueList;
    while ((line = br.readLine()) != null) {
      line = line.trim();
      if (line.trim().length() == 0) {
        continue;
      }
      //System.out.println(line);
      cells = line.split("\t");

      if (cells[index].equals("-nan")) {
        continue;
      }
      if (cells[index].equals("NA")) {
        continue;
      }
      if (cells[index].equals(".")) {
        continue;
      }
      pvalueMap.add(cells);
    }

    Collections.sort(pvalueMap, new StringArrayDoubleComparator(index));
    for (int i = 0; i < pvalueMap.size(); i++) {
      pValueList.add(Double.parseDouble(pvalueMap.get(i)[index]));
    }

    adjustPValueList = benjaminiHochbergFDR(pValueList);
    // cutoff = 0.05 / pValueList[j].size();
    double value;
    for (int i = 0; i < 10; i++) {
      String[] item = pvalueMap.get(i);
      System.out.print(item[0] + "\t" + item[1] + "\t" + item[2]);
      for (int t = 3; t < item.length - 1; t++) {
        value = Double.parseDouble(item[t]);
        System.out.print("\t");
        if (value < 0.01) {
          System.out.print(String.format("%.2e", value));
        } else {
          System.out.print(String.format("%.2f", value));
        }
      }

      System.out.print("\t");
      value = adjustPValueList[i];
      if (value < 0.01) {
        System.out.print(String.format("%.2e", value));
      } else {
        System.out.print(String.format("%.2f", value));
      }
      System.out.print("\t");
      System.out.print(item[item.length - 1]);
      System.out.println();

    }
    int sss = 0;
  }

  public void readPValues(String pValueFilePath, int[] index) throws Exception {
    BufferedReader br = LocalFileFunc.getBufferedReader(pValueFilePath);
    String line = br.readLine();
    String[] cells;
    List<String[]> pvalueMap = new ArrayList<String[]>();
    String[] pvs = null;
    DoubleArrayList pValueList = new DoubleArrayList();
    double[] adjustPValueList;
    int missing = 0;
    int orgLen = 0;
    while ((line = br.readLine()) != null) {
      line = line.trim();
      if (line.trim().length() == 0) {
        continue;
      }
      //System.out.println(line);
      cells = line.split("\t");
      missing = 0;
      for (int i = 0; i < index.length; i++) {
        if (cells[index[i]].equals("-nan")) {
          cells[index[i]] = "1";
          missing++;
        } else if (cells[index[i]].equals("NA")) {
          cells[index[i]] = "1";
          missing++;
        } else if (cells[index[i]].equals(".")) {
          cells[index[i]] = "1";
          missing++;
        }
      }
      if (missing == index.length) {
        continue;
      }
      String[] newCells = new String[cells.length + index.length];
      System.arraycopy(cells, 0, newCells, 0, cells.length);
      pvalueMap.add(newCells);
    }
    orgLen = pvalueMap.get(0).length - index.length;
    for (int i = 0; i < index.length; i++) {
      Collections.sort(pvalueMap, new StringArrayDoubleComparator(index[i]));
      for (int t = 0; t < pvalueMap.size(); t++) {
        cells = pvalueMap.get(t);
        missing = 0;
        if (cells[index[i]].equals("-nan")) {
          missing++;
        } else if (cells[index[i]].equals("NA")) {
          missing++;
        } else if (cells[index[i]].equals(".")) {
          missing++;
        }
        if (missing > 0) {
          continue;
        }
        pValueList.add(Double.parseDouble(cells[index[i]]));
      }
      adjustPValueList = benjaminiHochbergFDR(pValueList);
      for (int t = 0; t < adjustPValueList.length; t++) {
        cells = pvalueMap.get(t);
        cells[orgLen + i] = String.valueOf(adjustPValueList[t]);
      }
      pValueList.clear();
    }

    // cutoff = 0.05 / pValueList[j].size();
    double value;
    int outputNum = 5;
    Set<String> availableGene = new HashSet<String>();
    for (int j = 0; j < index.length; j++) {
      Collections.sort(pvalueMap, new StringArrayDoubleComparator(index[j]));
      for (int i = 0; i < outputNum; i++) {
        cells = pvalueMap.get(i);
        if (availableGene.contains(cells[0])) {
          continue;
        }
        availableGene.add(cells[0]);

        System.out.print(cells[0]);
        System.out.print("\t");
        System.out.print(cells[orgLen - 1]);
        for (int t = 0; t < index.length; t++) {
          value = Double.parseDouble(cells[index[t]]);
          System.out.print("\t");
          if (value < 0.01) {
            System.out.print(String.format("%.2e", value));
          } else {
            System.out.print(String.format("%.2f", value));
          }
          value = Double.parseDouble(cells[orgLen + t]);
          System.out.print("\t");
          if (value < 0.01) {
            System.out.print(String.format("%.2e", value));
          } else {
            System.out.print(String.format("%.2f", value));
          }
        }

        System.out.println();

      }
    }
    int sss = 0;
  }

  class StringArrayDoubleComparator implements Comparator<String[]> {

    private int index = 0;

    public StringArrayDoubleComparator(int ind) {
      this.index = ind;
    }

    @Override
    public int compare(String[] o1, String[] o2) {
      if (o1[index] == null || o2[index] == null || o1[index].equals(".") || o2[index].equals(".")) {
        return 0;
      }
      return Double.compare(Double.parseDouble(o1[index]), Double.parseDouble(o2[index]));
    }
  }

  public static double[] benjaminiHochbergFDR(DoubleArrayList sp) {
    int ti = sp.size();
    if (ti == 0) {
      return null;
    }
    // BH 
    double[] pv_BH = new double[ti];
    double t = (double) ti;

    pv_BH[ti - 1] = sp.getQuick(ti - 1);
    double x = 0;
    for (int i = ti - 2; i >= 0; i--) {
      x = (t / (double) (i + 1)) * sp.getQuick(i) < 1 ? (t / (double) (i + 1)) * sp.getQuick(i) : 1;
      pv_BH[i] = pv_BH[i + 1] < x ? pv_BH[i + 1] : x;
    }

    return pv_BH;
  }

  public static void main(String[] args) {
    // TODO code application logic here
    PValueParser cm = new PValueParser();
    try {
      //cm.readPValues("/home/user/work/java/kggseq/rener/noSynad.gene.mutationrate.txt", 6);
      cm.readPValues("/home/user/work/java/kggseq/rener/noSynasd.gene.mutationrate.txt", 6);

      cm.readPValues("/home/user/work/java/kggseq/rener/noSynadrvtest.rvtest.gene.txt", new int[]{1, 2, 3, 4});
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }
}
